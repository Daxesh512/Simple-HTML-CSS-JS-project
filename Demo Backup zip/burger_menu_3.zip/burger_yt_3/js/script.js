function toggleMenu() {
    document.querySelector('.burger').classList.toggle('active');
    document.querySelector('.menu').classList.toggle('active');
}
public class TrustLevel {
    enum Level 
    { 
        COMPLETE, 
        SOMEWHAT, 
        LITTLE, 
        NONE, 
    } 
    public Level level;
}

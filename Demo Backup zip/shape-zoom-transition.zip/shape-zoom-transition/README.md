# Shape Zoom Transition

A Pen created on CodePen.io. Original URL: [https://codepen.io/lonekorean/pen/zYRjwQx](https://codepen.io/lonekorean/pen/zYRjwQx).

A neat transition effect made with CSS masking and an SVG.

Read more: [Star Wars Scene Transition Effects in CSS](https://codersblock.com/blog/star-wars-scene-transition-effects-in-css/)
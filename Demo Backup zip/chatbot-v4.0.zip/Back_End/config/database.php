<?php
require_once 'EasySQL.php';

$hostname = "localhost";
$dbName = "ai";
$username = "root";
$password = "apkapikapm12";

$db = new EasySQL($hostname, $dbName, $username, $password);
import './index.scss';

function App() {
  return (
    <div className="App">
      <div>
        <h2>Счетчик:</h2>
        <h1></h1>
        <button className="minus">-</button>
        <button className="plus">+</button>
      </div>
    </div>
  );
}

export default App;
